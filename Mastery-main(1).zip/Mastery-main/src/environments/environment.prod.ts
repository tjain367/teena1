export const environment = {
  secretkey:'seretkey',
  apiUrl: 'https://matery-5d74a-default-rtdb.firebaseio.com/',
  firebaseConfig : {
    apiKey: "AIzaSyD30Lua_SDRwbIYd4rETmuY_NfV3AquU2Q",
    authDomain: "matery-5d74a.firebaseapp.com",
    projectId: "matery-5d74a",
    storageBucket: "matery-5d74a.appspot.com",
    messagingSenderId: "550238335312",
    appId: "1:550238335312:web:2eabcd1bd5346db3173c55"
  },
  production: true
};
