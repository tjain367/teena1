import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-dontate',
  templateUrl: './edit-dontate.component.html',
  styleUrls: ['./edit-dontate.component.css']
})
export class EditDontateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
