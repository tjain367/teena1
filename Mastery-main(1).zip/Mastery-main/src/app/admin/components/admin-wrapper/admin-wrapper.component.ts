import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-wrapper',
  templateUrl: './admin-wrapper.component.html',
  styleUrls: ['./admin-wrapper.component.css']
})
export class AdminWrapperComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

}
