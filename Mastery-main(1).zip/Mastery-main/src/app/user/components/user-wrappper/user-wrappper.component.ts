import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-wrappper',
  templateUrl: './user-wrappper.component.html',
  styleUrls: ['./user-wrappper.component.css']
})
export class UserWrappperComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
   
  }

}
